from django.apps import AppConfig


class ToothTalkAppConfig(AppConfig):
    name = 'tooth_talk_app'
