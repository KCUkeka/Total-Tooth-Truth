
$(document).ready(function () {
  $("#register").click(function () {
    $("#reg_form").toggle();
  });
});